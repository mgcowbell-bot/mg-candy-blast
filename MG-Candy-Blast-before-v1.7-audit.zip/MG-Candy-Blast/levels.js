/* MG Candy Blast - UNLIMITED levels. Level n is generated from n (same level every time), worlds repeat every 100 levels. */
const WORLDS=[null,{n:1,name:'Candy Village'},{n:2,name:'Chocolate Mountains'},{n:3,name:'Lollipop Forest'},{n:4,name:'Jelly Kingdom'},{n:5,name:'Rainbow Castle'}];
const BOOSTERS=['hammer','striped','bomb','extra','hand'];
const MAX_LEVEL=99999;
function worldOf(n){return ((Math.ceil(n/20)-1)%5)+1;}
function cycleOf(n){return Math.floor((Math.ceil(n/20)-1)/5);}
function makeLevel(n){
  const rnd=a=>{let s=a>>>0;return()=>{s=(s+0x6D2B79F5)|0;let t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};};
  const r=rnd(n*7919+13),world=worldOf(n),mf=Math.min(n,160),diff=Math.min(10,1+Math.floor((n-1)/10));
  let cols=8,rows=8;
  if(n>10){ if(n%7===0){cols=7;rows=9;} else if(n%5===0){cols=7;rows=7;} }
  const types=n<=5?5:6;
  const kindEarly=n<=10;
  const moves=Math.max(12,(n<=10?26:28)-Math.floor(Math.min(n,100)/6)+(n%3===0?1:0));
  const ratio=n<=5?.1+.03*n:Math.min(.95,.45+.006*Math.min(n,100)),perMove=types===5?570:260;
  const target=Math.max(1000,Math.round(moves*perMove*ratio/100)*100);
  const kinds=n<=3?'score':n<=10?(n%2?'collect':'score'):['score','collect','jelly','choc','special','multi'][(n+Math.floor(n/6))%6];
  const kind=kinds;
  const objMoves=kind==='jelly'?(n>100?11:8):kind==='multi'?(n>100?12:10):kind==='choc'?4:kind==='special'?3:0;
  const cfg={n,world,cols,rows,types,moves:moves+objMoves,score:target,stars:[target,Math.round(target*1.35/100)*100,Math.round(target*1.8/100)*100],
    collect:{},jelly:[],choc:[],special:0,difficulty:diff,theme:world,
    boosters:n<3?[]:n<10?['hammer','extra']:BOOSTERS.slice(),extraLimit:2,kind,obj:[]};
  const wantCollect=kind==='collect'||kind==='multi',wantJelly=kind==='jelly'||kind==='multi';
  const wantChoc=kind==='choc'||(kind==='multi'&&n>30&&n%2===0),wantSpecial=kind==='special'||(kind==='multi'&&n>45&&n<=100&&n%2===1);
  if(wantCollect){const k=kind==='multi'?1:(n>40?2:1);const pool=[...Array(types).keys()];
    for(let i=0;i<k;i++){const t=pool.splice(Math.floor(r()*pool.length),1)[0];cfg.collect[t]=Math.max(10,Math.round(moves*3.0/types*(0.85+diff*0.10)));}}
  if(wantJelly){const cnt=Math.round(Math.min(Math.floor(rows*cols*.4),8+Math.floor(Math.min(n,100)/7))*(kind==='multi'?.65:1)),layers=n>60?2:1,set=new Set();let g=0;
    while(set.size<cnt&&g++<500){set.add(Math.floor(r()*rows)*cols+Math.floor(r()*cols));}
    set.forEach(i=>cfg.jelly.push([i%cols,Math.floor(i/cols),(layers===2&&r()<.25)?2:1]));}
  if(wantChoc){const cnt=Math.min(18,3+Math.floor(Math.min(n,150)/7)),set=new Set();let g=0;
    while(set.size<cnt&&g++<500){set.add((1+Math.floor(r()*(rows-1)))*cols+Math.floor(r()*cols));}
    set.forEach(i=>cfg.choc.push([i%cols,Math.floor(i/cols)]));}
  if(wantSpecial)cfg.special=Math.min(8,3+Math.floor(n/14));
  if(wantCollect)cfg.obj.push('collect');if(wantJelly)cfg.obj.push('jelly');if(wantChoc)cfg.obj.push('choc');if(wantSpecial)cfg.obj.push('special');
  // THREE-STAR RULE: a level is won only when every goal is done AND the 3-star score (cfg.score = stars[2]) is reached.
  const goalScore=(kind==='score'||n<=3)?target:Math.max(800,Math.round(target*(kind==='multi'?.45:.55)/100)*100);
  cfg.score=goalScore;cfg.stars=[Math.round(goalScore*.5/100)*100,Math.round(goalScore*.75/100)*100,goalScore];
  cfg.obj.unshift('score');
  return cfg;
}
const _levelCache={};
const LEVELS=new Proxy({},{get(t,k){const n=+k;if(Number.isInteger(n)&&n>=1&&n<=MAX_LEVEL)return _levelCache[n]||(_levelCache[n]=makeLevel(n));return undefined;}});
if(typeof module!=='undefined')module.exports={LEVELS,WORLDS,worldOf,cycleOf,makeLevel};
