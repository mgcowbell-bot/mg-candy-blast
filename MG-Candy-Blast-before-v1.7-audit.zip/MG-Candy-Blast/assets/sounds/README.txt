All sounds and music are synthesized live with the Web Audio API in audio.js. No audio files are used.
