World backgrounds are painted procedurally by art.js (sky + land scenes for 5 themes) and cached at runtime.
