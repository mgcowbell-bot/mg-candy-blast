Candy artwork is drawn procedurally on canvas by art.js (6 candies, striped, wrapped, color bomb, chocolate) so no image files are needed.
